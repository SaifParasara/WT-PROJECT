//import logo from './logo.svg';
import './App.css';
import Weather from './Components/Weather';
import Myapp from './Components/Myapp';

function App() {
  return (
    <>
      
      <Myapp/>
    </>
  );
}

export default App;
